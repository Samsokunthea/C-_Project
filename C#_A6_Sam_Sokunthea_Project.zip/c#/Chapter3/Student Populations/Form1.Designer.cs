﻿namespace Student_Populations
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNumberofstudent = new System.Windows.Forms.TextBox();
            this.txtAnnualgrowthrate = new System.Windows.Forms.TextBox();
            this.txtNumberofyear = new System.Windows.Forms.TextBox();
            this.txtProjectednumber = new System.Windows.Forms.TextBox();
            this.btnProjected = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(91, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of Student today:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(91, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Annual growth rate:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(91, 188);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Number of years:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(91, 254);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(222, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Projected number of students:";
            // 
            // txtNumberofstudent
            // 
            this.txtNumberofstudent.Location = new System.Drawing.Point(380, 51);
            this.txtNumberofstudent.Name = "txtNumberofstudent";
            this.txtNumberofstudent.Size = new System.Drawing.Size(185, 26);
            this.txtNumberofstudent.TabIndex = 4;
            this.txtNumberofstudent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAnnualgrowthrate
            // 
            this.txtAnnualgrowthrate.Location = new System.Drawing.Point(380, 114);
            this.txtAnnualgrowthrate.Name = "txtAnnualgrowthrate";
            this.txtAnnualgrowthrate.Size = new System.Drawing.Size(185, 26);
            this.txtAnnualgrowthrate.TabIndex = 5;
            this.txtAnnualgrowthrate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberofyear
            // 
            this.txtNumberofyear.Location = new System.Drawing.Point(380, 182);
            this.txtNumberofyear.Name = "txtNumberofyear";
            this.txtNumberofyear.ReadOnly = true;
            this.txtNumberofyear.Size = new System.Drawing.Size(185, 26);
            this.txtNumberofyear.TabIndex = 6;
            this.txtNumberofyear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtProjectednumber
            // 
            this.txtProjectednumber.Location = new System.Drawing.Point(380, 248);
            this.txtProjectednumber.Name = "txtProjectednumber";
            this.txtProjectednumber.ReadOnly = true;
            this.txtProjectednumber.Size = new System.Drawing.Size(185, 26);
            this.txtProjectednumber.TabIndex = 7;
            this.txtProjectednumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnProjected
            // 
            this.btnProjected.Location = new System.Drawing.Point(129, 309);
            this.btnProjected.Name = "btnProjected";
            this.btnProjected.Size = new System.Drawing.Size(119, 71);
            this.btnProjected.TabIndex = 8;
            this.btnProjected.Text = "&Projected Student Population";
            this.btnProjected.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(396, 309);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(119, 71);
            this.btnExit.TabIndex = 9;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AcceptButton = this.btnProjected;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnProjected);
            this.Controls.Add(this.txtProjectednumber);
            this.Controls.Add(this.txtNumberofyear);
            this.Controls.Add(this.txtAnnualgrowthrate);
            this.Controls.Add(this.txtNumberofstudent);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Student Population";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNumberofstudent;
        private System.Windows.Forms.TextBox txtAnnualgrowthrate;
        private System.Windows.Forms.TextBox txtNumberofyear;
        private System.Windows.Forms.TextBox txtProjectednumber;
        private System.Windows.Forms.Button btnProjected;
        private System.Windows.Forms.Button btnExit;
    }
}

