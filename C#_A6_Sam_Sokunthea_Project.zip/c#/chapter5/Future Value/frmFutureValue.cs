﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Future_Value
{
    public partial class frmFutureValue : Form
    {
        public frmFutureValue()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal monthly=Convert.ToDecimal(txtMonthlyInvestment.Text);
            decimal yearly=Convert.ToDecimal(txtYearlyInterestRate.Text);
            int numY = Convert.ToInt32(txtNumberofYears.Text);

            int month = numY * 12;
            decimal monthyrate = yearly / 12 / 100;

            decimal future = 0m;
            for (int i = 0; i<month; i++)
            {
                future = (future + monthly) * (1 + monthyrate);
            }
            txtFutureValue.Text = future.ToString("c");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
