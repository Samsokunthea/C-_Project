﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Invoice_total2
{
    public partial class frmInvoiceTotal : Form
    {
        public frmInvoiceTotal()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal subtotal=Convert.ToDecimal(txtSubtotal.Text);
            String customertype = txtCustomerType.Text;
            if (customertype == "R".ToLower())
            {
                if(subtotal >= 250 &&  subtotal <= 500)
                {
                    decimal discountPercent = .25m;
                    decimal discountAmount = subtotal * discountPercent;
                    decimal invoice = subtotal - discountAmount;

                    txtDcountpercent.Text = discountPercent.ToString("c");
                    txtDiscountAmount.Text = discountAmount.ToString("c");
                    txtTotal.Text = invoice.ToString("c");
                }
                else
                {
                    decimal discountPercent = .30m;
                    decimal discountAmount = subtotal * discountPercent;
                    decimal invoice = subtotal - discountAmount;

                    txtDcountpercent.Text = discountPercent.ToString("p1");
                    txtDiscountAmount.Text = discountAmount.ToString("c");
                    txtTotal.Text = invoice.ToString("c");
                }
            }
            else if(customertype == "C".ToLower())
            {
                decimal discountPercent = .20m;
                decimal discountAmount = subtotal * discountPercent;
                decimal invoice=subtotal-discountAmount;

                txtDcountpercent.Text=discountPercent.ToString("p1");
                txtDiscountAmount.Text = discountAmount.ToString("c");
                txtTotal.Text=invoice.ToString("c");
            }
            else if(customertype == "T".ToLower())
            {
                if (subtotal < 500)
                {
                    decimal discountPercent = .40m;
                    decimal discountAmount = subtotal * discountPercent;
                    decimal invoice = subtotal - discountAmount;

                    txtDcountpercent.Text = discountPercent.ToString("p1");
                    txtDiscountAmount.Text = discountAmount.ToString("c");
                    txtTotal.Text = invoice.ToString("c");
                }
                else
                {
                    decimal discountPercent = .50m;
                    decimal discountAmount = subtotal * discountPercent;
                    decimal invoice = subtotal - discountAmount;

                    txtDcountpercent.Text = discountPercent.ToString("p1");
                    txtDiscountAmount.Text = discountAmount.ToString("c");
                    txtTotal.Text = invoice.ToString("c");
                }
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
