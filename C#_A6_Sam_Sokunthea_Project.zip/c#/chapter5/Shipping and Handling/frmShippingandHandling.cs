﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shipping_and_Handling
{
    public partial class frmShippingandHandling : Form
    {
        public frmShippingandHandling()
        {
            InitializeComponent();
        }
       
        private void btnCalculateGrandTotal_Click(object sender, EventArgs e)
        {
            String order = txtOrderTotal.Text;
            decimal OrderTotal = Convert.ToDecimal(order);
            String custumerType = txtCustomerType.Text;
            decimal saleTax = 7m;
            if( custumerType == "P".ToLower() )
            {
                decimal ShippingCost = .0m;
                txtShippingCosts.Text = ShippingCost.ToString("c");
                txtSalesTax.Text= saleTax.ToString("c");
                decimal total = OrderTotal + saleTax;
                txtGrandTotal.Text = total.ToString("c");
            }
            else if( custumerType == "N".ToLower())
            {
                if(OrderTotal>=.0m && OrderTotal<= 25.0m)
                {
                    decimal ShippingCost = 5.0m;
                    txtShippingCosts.Text = ShippingCost.ToString("c");
                    txtSalesTax.Text=saleTax.ToString("c");
                    decimal total = OrderTotal + saleTax + ShippingCost;
                    txtGrandTotal.Text= total.ToString("c");
                }
                else if(OrderTotal>=25.01m && OrderTotal <= 500.00m)
                {
                    decimal Shipping = 8.0m;
                    txtShippingCosts.Text=Shipping.ToString("c");
                    txtSalesTax.Text=saleTax.ToString("c");
                    decimal total = OrderTotal + saleTax + Shipping;
                    txtGrandTotal.Text=total.ToString("c");
                }
                else if (OrderTotal >= 500.01m && OrderTotal <= 1000.00m)
                {
                    decimal Shipping = 10.0m;
                    txtShippingCosts.Text = Shipping.ToString("c");
                    txtSalesTax.Text = saleTax.ToString("c");
                    decimal total = OrderTotal + saleTax + Shipping;
                    txtGrandTotal.Text = total.ToString("c");
                }
                else if (OrderTotal >= 1000.01m && OrderTotal <= 5000.00m)
                {
                    decimal Shipping = 15.0m;
                    txtShippingCosts.Text = Shipping.ToString("c");
                    txtSalesTax.Text = saleTax.ToString("c");
                    decimal total = OrderTotal + saleTax + Shipping;
                    txtGrandTotal.Text = total.ToString("c");
                }
                else
                {
                    decimal Shipping = 20.0m;
                    txtShippingCosts.Text = Shipping.ToString("c");
                    txtSalesTax.Text = saleTax.ToString("c");
                    decimal total = OrderTotal + saleTax + Shipping;
                    txtGrandTotal.Text = total.ToString("c");
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
