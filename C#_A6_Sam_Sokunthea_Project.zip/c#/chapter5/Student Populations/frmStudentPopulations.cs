﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Populations
{
    public partial class frmStudentPopulations : Form
    {
        public frmStudentPopulations()
        {
            InitializeComponent();
        }

        private void btnProjected_Click(object sender, EventArgs e)
        {
            double numberofstudent = Convert.ToDouble(txtNumberofstudent.Text);
            double annualgrowth = Convert.ToDouble(txtAnnualgrowthrate.Text);
            decimal numberofyeat = Convert.ToDecimal(txtNumberofyear.Text);
            int i = 1;
            while (i <= 5)
            {
                numberofstudent = numberofstudent * (1 + annualgrowth);
                i += 1;
            }
            txtProjectednumber.Text = numberofstudent.ToString("f3");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
