﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Telephone_number
{
    public partial class frmTelephoneNumber : Form
    {
        public frmTelephoneNumber()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            String convert=(txtAlphanumericNumber.Text);
            txtNumbericOnly.Text = " ";
            int stringlength = convert.Length;
            for (int i = 0; i < stringlength; i++)
            {
                String ch = convert.Substring(i, 1).ToLower();
                if (ch == "a" || ch == "b" || ch == "c")
                {
                    txtNumbericOnly.Text += "2";
                }
                else if (ch == "d" || ch == "e" || ch == "f")
                {
                    txtNumbericOnly.Text += "3";
                }
                else if (ch == "g" || ch == "h" || ch == "i")
                {
                    txtNumbericOnly.Text += "4";
                }
                else if (ch == "j" || ch == "k" || ch == "l")
                {
                    txtNumbericOnly.Text += "5";
                }
                else if (ch == "m" || ch == "n" || ch == "o")
                {
                    txtNumbericOnly.Text += "6";
                }
                else if (ch == "p" || ch == "q" || ch == "r" || ch == "s")
                {
                    txtNumbericOnly.Text += "7";
                }
                else if (ch == "t" || ch == "u" || ch == "v")
                {
                    txtNumbericOnly.Text += "8";
                }
                else if(ch=="w" || ch=="y" || ch == "z")
                {
                    txtNumbericOnly.Text += "9";
                }
                else
                {
                    txtNumbericOnly.Text += ch;
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
