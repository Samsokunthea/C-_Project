﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Future_Value
{
    public partial class frmFutureValue : Form
    {
        public frmFutureValue()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int monthly=Convert.ToInt16(txtMonthlyInvestment.Text);
            decimal yearly=Convert.ToDecimal(txtYearlyInterestRate.Text);
            int numY = Convert.ToInt32(txtNumberofYears.Text);

            int month = numY * 12;
            decimal monthlyrate = yearly / 12 / 100;

            decimal future = this.CalculateFutureValue(month, monthlyrate, monthly);

            txtFutureValue.Text = future.ToString("c");
        }

        private decimal CalculateFutureValue(decimal monthlyrate, decimal month, int monthly)
        {
            decimal future = 0m;
            for (int i = 0; i < month; i++)
            {
                future = (future + monthly) * (1 + monthlyrate);
            }
            return future;
        }

        private void clearFutureValue(object sender, EventArgs e)
        {
            txtFutureValue.Text = " ";
        }



        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            this.clearFutureValue(sender, EventArgs.Empty);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
