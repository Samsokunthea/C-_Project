﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Future_Value
{
    public partial class frmFutureValue : Form
    {
        public frmFutureValue()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsValidData())
                {
                    int monthly = Convert.ToInt16(txtMonthlyInvestment.Text);
                    decimal yearly = Convert.ToDecimal(txtYearlyInterestRate.Text);
                    int numY = Convert.ToInt32(txtNumberofYears.Text);

                    int month = numY * 12;
                    decimal monthlyrate = yearly / 12 / 100;

                    decimal future = this.CalculateFutureValue(month, monthlyrate, monthly);

                    txtFutureValue.Text = future.ToString("c");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message + "\n\n" + ex.GetType().ToString() + "\n" + ex.StackTrace, "Exception");
            }
        }

        public bool IsValidData()
        {
            return
                IsPresent(txtMonthlyInvestment, "Monthly Invesment") &&
                IsDecimal(txtMonthlyInvestment, "MothlyInvestment") &&
                IsWithinRange(txtMonthlyInvestment, "Monthly Investment", 1, 1000) &&
                IsPresent(txtYearlyInterestRate, "Yearly Interest Rate") &&
                IsDecimal(txtYearlyInterestRate, "Yearly Interest Rate") &&
                IsWithinRange(txtYearlyInterestRate, "Yearly Interest Rate", 1, 20) &&

                IsPresent(txtNumberofYears, "Number of Years") &&
                IsInt32(txtNumberofYears, "Number of Years") &&
                IsWithinRange(txtNumberofYears, "Number of Years", 1, 40);
        }

        public bool IsPresent(TextBox textBox, string name)
        {
            if (textBox.Text == " ")
            {
                MessageBox.Show(name + "is a require field.", "Enter Error");
                textBox.Focus();
                return false;
            }
            return true;
        }

        public bool IsDecimal(TextBox textBox, string name) {
            try
            {
                Convert.ToDecimal(textBox.Text);
                return true;
            }        
            catch(FormatException) {
                MessageBox.Show(name + "must be a decimal value","Entery Error");
                textBox.Focus();
                return false;
            }
        }

        public bool IsInt32(TextBox textBox, string name)
        {
            try
            {
                Convert.ToInt32(textBox.Text);
                return true;
            }
            catch (FormatException)
            {
                MessageBox.Show(name + "must be an integer", "Entery Error");
                textBox.Focus();
                return false;
            }
        }

        public bool IsWithinRange(TextBox textBox, String name, decimal min, decimal max)
        {
            decimal number = Convert.ToDecimal(textBox.Text);
            if(number < min || number > max)
            {
                MessageBox.Show(name + "must be between " + min + "and" + max + ".", "Entery Error");
                textBox.Focus();
                return false;
            }
            return true;
        }
       
        private decimal CalculateFutureValue(decimal monthlyrate, decimal month, int monthly)
        {
            decimal future = 0m;
            for (int i = 0; i < month; i++)
            {
                future = (future + monthly) * (1 + monthlyrate);
            }
            return future;
        }

        private void clearFutureValue(object sender, EventArgs e)
        {
            txtFutureValue.Text = " ";
        }



        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            this.clearFutureValue(sender, EventArgs.Empty);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
